My NES
======
A Nintendo Entertainment System / Family Computer (Nes/Famicom) Emulator written in C#.
Copyright � Ala Ibrahim Hadid 2009 - 2014
Email: mailto:ahdsoftwares@hotmail.com

WARNING!
========
-Installing and using this software is done at your own risk, read the license for more details.

COPYING
=======
My Nes is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

My Nes is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

IMPORTANT!
==========
System Requirements:

* OS: Microsoft Windows� XP / Vista / 8 and 8.1. Not tested on older versions. 
* Processor: 2 GHz or faster (Intel or AMD) 
* Memory: 256 Mb RAM or larger 
* Microsoft .Net Framework 4.0.
* SlimDX Runtime or SlimDX SDK for .NET 4.0 (January 2012), please visit http://slimdx.org/ for more. 
* Drivers: Please install the latest DirectX end-user redistributable package from Microsoft.

THIS IS BETA !
--------------
To see the version of My Nes, open the about box (in My Nes main window, go to Help>About menu item)
This version of My Nes is BETA; which means it's incomplete.
The purpose of this release is to test My Nes features and to collect user feedbacks as much as possible....
My Nes works basically, My Nes core is complete ! the only thing left is the GUI (user interface), NetPlay
,implmenting the boards (or mappers) and other small features like Zapper.
Your ideas, feedbacks, bug reports and anything is welcomed at this e-mail: ahdsoftwares@hotmail.com

To report a bug or to request a feature please visit this page:
https://sourceforge.net/p/mynes/_list/tickets

You can always get the latest source updateds in the code page [SVN commits]:
https://sourceforge.net/p/mynes/code/HEAD/tree/trunk/

Also you can discuse My Nes stuff here:
https://sourceforge.net/p/mynes/discussion/

Follow My Nes in facebook:
https://www.facebook.com/pages/My-Nes/427707727244076?ref=hl

Enjoy !

END OF README DOCUMENT
----------------------